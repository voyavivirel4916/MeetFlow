"""HTTP entry points."""
